class Bullet {
    constructor(x,y) {
      this.x = x;
      this.y = y;
      this.velocity = 10;
    }
    
   draw() {
        image(ch1bullet,this.x + 50, this.y + 50, 15, 15)
   }
        
    update() {  // 왼쪽으로 슈팅
        this.x -= this.velocity;
        print(this.x)
    }

    update1() { // 오른으로 슈팅
        this.x += this.velocity;
        print(this.x)
    }

    reset() {
      this.x = - 10;
      this.y = - 10;
    }
}
  